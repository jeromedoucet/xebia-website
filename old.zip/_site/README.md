xebia-website
=============

Project board: https://trello.com/board/corporate-web-site-2012/4fe319d537985068397de16d

New version of Xebia's website

This website has to be both a showcase for Xebia's offers and a POC for new Webtechnologies (HTML5, CSS3)

The website runs with jekyll : (http://jekyllrb.com/)

1. Install jekyll ( > sudo gem install jekyll)
2. Change directory to the projects root directory
3. Run with "jekyll --server"
4. Open your browser http://localhost:4000


!! If you want to run the application in a standalone mode (the _site folder) you have to use firefox !! 